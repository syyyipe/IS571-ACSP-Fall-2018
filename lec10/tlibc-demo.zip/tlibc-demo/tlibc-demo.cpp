// tlibc-demo.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"

int _tmain(int argc, _TCHAR* argv[])
{
	char buf[100];
	char *buf_p = (char *)malloc(100);

	memset(buf, 0, sizeof(buf));

	strcpy(buf, "AAAAA");
	strcpy(buf_p, "BBBBB");

	MessageBoxA(0, buf, 0, 0);
	MessageBoxA(0, buf_p, 0, 0);

	return 0;
}
