// lec08.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"
#include <windows.h>  
#include <memory.h>
#include <stdio.h>
#include <stdio.h>  
#include <malloc.h>  
#include <algorithm>

// ////////////////////////////////////////////////////////////////////////////
// lec08_my_array.exe
#define MAXSIZE_ARRAY 0x10000
#define EMPTY_VALUE   0xDEADF00D

class MyIntArray {

private:
	int m_length;
	int *m_pArray = NULL;

public:
	MyIntArray(int length) 
	{
		if (length > MAXSIZE_ARRAY)
			throw EXCEPTION_ARRAY_BOUNDS_EXCEEDED;

		m_length = length;
		m_pArray = (int *)malloc(MAXSIZE_ARRAY * sizeof(int));
		
		for (int i = 0; i < length; i++)
			m_pArray[i] = EMPTY_VALUE;
	}

	~MyIntArray() 
	{
		free(m_pArray);
	}

	inline int getLength() { return m_length; }

	void setLength(int length)
	{
		if (length > MAXSIZE_ARRAY)
			throw EXCEPTION_ARRAY_BOUNDS_EXCEEDED;

		int *newArray = (int *)malloc(MAXSIZE_ARRAY * sizeof(int));

		for (int i = 0; i < length; i++)
			newArray[i] = EMPTY_VALUE;

		for (int i = 0; i < m_length; i++)
			newArray[i] = m_pArray[i];
		
		m_length = 0;
		free(m_pArray);
		
		m_pArray = newArray;
		m_length = length;
	}

	int operator [](int index) const 
	{
		if (index < 0 || index > m_length - 1) {
			printf("error: out of index\n");
			throw EXCEPTION_ARRAY_BOUNDS_EXCEEDED;
		}
		return m_pArray[index];
	}

	int& operator [](int index) 
	{
		if (index < 0 || index > m_length - 1) {
			printf("error: out of index\n");
			throw EXCEPTION_ARRAY_BOUNDS_EXCEEDED;
		}

		//printf("-->index: %x\n", index);
		//printf("-->m_pArray[index]: %x\n", &m_pArray[index]);

		return m_pArray[index];
	}

	int itemsOf()
	{
		int items = 0;
		for (int i = 0; i < m_length; i++) {
			if (m_pArray[i] == EMPTY_VALUE) {
				items = i;
				break;
			}
		}
		return items;
	}

	void info()
	{
		printf("buffer: %x\n", &m_pArray);
		printf("length: %d(%x)\n", m_length, m_length);
	}

	void print(bool endline = false) 
	{
		int items = itemsOf();
		printf("{");
		for (int i = 0; i < items; i++) {
			if (m_pArray[i] != EMPTY_VALUE)
				printf("%d", m_pArray[i]);
			if (i != items - 1)
				printf(",");
		}
		printf("}");
		if (endline)
			printf("\n");
	}
};

int main(int argc, char* argv[])
{
	// declare local variables
	char buf[0100] = {'\0'};
	MyIntArray mia(100);

	printf("-> buf address: 0x%x\n", buf);
	printf("-> mia address: 0x%x\n", &mia);

	while (1) 
	{
		printf("Command> ");

		fgets(buf, 0x100, stdin);
		buf[strlen(buf) - 1] = '\0';

		try {
			if (!strcmp(buf, "") || strstr(buf, "gets")) {
				mia.print(true);
			}
			else
			if (strstr(buf, "get")) {
				char *c = strstr(buf, "get") + 4;
				int index = atoi(c);
				printf("[%d] = %d\n", index, mia[index]);
			}
			else
			if (strstr(buf, "sets")) {
				char *c = strstr(buf, "sets") + 5;
				int i = 0;
				char *no = strtok(c, ", ");
				while (no != NULL) {
					mia[i++] = atoi(no);
					no = strtok(NULL, ", ");
				}
				mia.print(true);
			}
			else
			if (strstr(buf, "set")) {
				char *c = strstr(buf, "set") + 4;
				char *no = strtok(c, ",=: ");
				if (!no)
					continue;

				int index = atoi(no);
				no = strtok(NULL, ",=: ");
				if (!no)
					continue;

				int value = atoi(no);
				mia[index] = value;

				printf("[%d] = %d\n", index, mia[index]);
			}
			else
			if (strstr(buf, "info")) {
				mia.info();
			}
			else 
			if (strstr(buf, "exit") || strstr(buf, "quit")) {
				exit(0);
			}
			else {
				printf("usage) sets 1,2,3,4,5,6,...\n");
				printf("       gets\n");
				printf("       set <index> <value>\n");
				printf("       get <index>\n");
				printf("       exit\n");
				continue;
			}
		}
		catch (...) {
		}
	}

	return 0;
}
